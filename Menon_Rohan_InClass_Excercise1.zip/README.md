# State Example #

This is the state example we did in class.  It passes a date prop to the Clock component and then uses the prop to set the date state in Clock. The tick function fires every second and updates the state which then updates the UI